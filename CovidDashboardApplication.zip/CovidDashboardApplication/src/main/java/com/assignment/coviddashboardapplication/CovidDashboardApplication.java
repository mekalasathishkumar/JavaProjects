package com.assignment.coviddashboardapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CovidDashboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(CovidDashboardApplication.class, args);
    }

}
