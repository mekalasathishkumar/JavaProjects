package com.assignment.coviddashboardapplication.service;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.assignment.coviddashboardapplication.entity.PatientData;
import com.assignment.coviddashboardapplication.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class CovidService {

    private final String REST_API_URL = "https://api.covidtracking.com/v1/states/{state}/current.json";

    //https://api.covidtracking.com/v1/states/ca/current.json
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private RestTemplate restTemplate;
    public String fetchCovidPatientsList(String state) {

         String patientData = fetchDataFromApi(state);
        // Save items to the database
       //patientRepository.save(patientData);
       return patientData;
    }
    public String fetchDataFromApi(String state) {
        String apiUrl = REST_API_URL;

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(apiUrl);
        String uri = builder.buildAndExpand(state).toUriString();
        System.out.println(" UI "+ uri);

        return restTemplate.getForObject(uri, String.class);
    }
}
