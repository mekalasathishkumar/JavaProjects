package com.assignment.coviddashboardapplication.controller;


import com.assignment.coviddashboardapplication.entity.PatientData;
import com.assignment.coviddashboardapplication.service.CovidService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {
    @Autowired
    private CovidService covidService;

    @GetMapping("/fetch-and-store")
    public String fetchAndStore(@RequestParam(value = "state") String state) {
        return "Data fetched and stored in the database for "+covidService.fetchCovidPatientsList(state).toString();
    }
}
